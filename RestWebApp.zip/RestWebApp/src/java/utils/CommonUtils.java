/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author divya
 */
public class CommonUtils {

    public String readFile() throws Exception {
        try (InputStream input = getClass().getResourceAsStream("search.json")) 
        {
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line);
            }
            System.out.println(out.toString());   //Prints the string content read from input stream
            reader.close();
            return out.toString();
        }
    }

    public int getMinPrice(String out) {
        int minPrice = 0;
        try {
            //  JSONArray obj = new JSONArray(out.toString()); // parse the array
            JSONObject jsonObj = new JSONObject(out);
            JSONArray jsonArray = jsonObj.getJSONArray("items");

            //  System.out.println("diya="+jsonArray.get(0));
            int currentPrice = 0;
            for (int i = 0; i < jsonArray.length(); i++) { // iterate over the array
                JSONObject o = jsonArray.getJSONObject(i);

                try {
                    currentPrice = o.getInt("salePrice");
                    if (i == 0) {
                        minPrice = currentPrice;
                    }
                    if (currentPrice < minPrice) {
                        minPrice = currentPrice;
                    }
                } catch (JSONException e) {

                }
            }
            // System.out.println("===minPrice is===: " + minPrice);
        } catch (Exception e) {
            System.out.println("in except=" + e);
        }
        return minPrice;
    }
}
