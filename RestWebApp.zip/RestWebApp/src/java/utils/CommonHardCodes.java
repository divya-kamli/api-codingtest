/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;


import java.io.InputStream;
import java.util.Properties;

public class CommonHardCodes {

    private static Properties appProperties;
  

    public static String getProperty(String paramString)
    {
        return appProperties.getProperty(paramString);
    }
   static
    {
        InputStream localInputStream = null;
        try
        {
            appProperties = new Properties();
            localInputStream = Class.forName("utils.CommonHardCodes").getResourceAsStream("/config/hardcode.properties");

            appProperties.load(localInputStream);
        }
        catch (Exception localException)
        {
            System.out.println("in localException");
        }
        finally
        {
            try
            {
                if (localInputStream != null)
                {
                    localInputStream.close();
                }
            }
            catch (Exception e)
            {
                System.out.println("in exception");
            }
        }
    }
   
   
}

