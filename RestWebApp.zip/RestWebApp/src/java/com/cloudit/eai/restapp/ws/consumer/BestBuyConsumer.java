/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cloudit.eai.restapp.ws.consumer;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import javax.ws.rs.core.MediaType;
import utils.CommonHardCodes;
import utils.CommonUtils;

/**
 *
 * @author divya
 */
public class BestBuyConsumer {
    
   public String getProductDetailsByItemName(String itemName)
    {
        String output = null;

        try {

            /* Start
            Below call to BestBuy url was giving status 404 so I have
            stored json output of api in json file and saved in it
            */
            Client client = Client.create();
         StringBuilder strUrl=new StringBuilder();
         strUrl.append(CommonHardCodes.getProperty("bestBuyUrl")).append("search=").append(itemName).append("&format=json&apiKey=").append(CommonHardCodes.getProperty("bestbuyApiKey"));
          
          WebResource webResource = client
                    .resource(strUrl.toString().trim());

   ClientResponse response = (ClientResponse) webResource
                    .accept(new String[]{
                        MediaType.APPLICATION_JSON
                    }).post(ClientResponse.class);
            
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + response.getStatus());
            }

            output = response.getEntity(String.class);
            /* End Code */
            
            CommonUtils commonObj=new CommonUtils();
            String jsonStr=commonObj.readFile();
            int minBestBuyPrice=commonObj.getMinPrice(jsonStr);
            
            
          
        } catch (Exception e) {
            //System.out.println("Exception >>" + e);
        }
        return output;
  
    }  
    
}
