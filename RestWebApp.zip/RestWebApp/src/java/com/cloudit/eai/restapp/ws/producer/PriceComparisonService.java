/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cloudit.eai.restapp.ws.producer;

import com.cloudit.eai.restapp.ws.consumer.BestBuyConsumer;
import com.cloudit.eai.restapp.ws.consumer.WalmartConsumer;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 *
 * @author divya
 */
@Path("/product")
public class PriceComparisonService {
    
    @GET
    @Path("/search")
    @Produces(
            {
                "application/json"
            })
    public String getItemDetails(String itemName) throws Exception
    {
        
        BestBuyConsumer bestBuyConsumer=new BestBuyConsumer();
        String bestBuyProductDetails=bestBuyConsumer.getProductDetailsByItemName(itemName);
        
        WalmartConsumer walmartConsumer=new WalmartConsumer();
        String walmartProductDetails=walmartConsumer.getProductDetailsByItemName(itemName);
        
        return (bestBuyProductDetails+walmartProductDetails);
    }
    
}
